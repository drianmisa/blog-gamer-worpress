<?php get_header(); ?>
<?php include(get_template_directory() . "/comp/single-post/comp-single-post.php"); ?>

<?php get_footer(); ?>