<?php get_header(); ?>

<?php include(get_template_directory() . "/comp/404/err-404.php"); ?>

<?php get_footer(); ?>
