<?php include(get_template_directory() . '/comp/footer/footer.php'); ?>
<?php wp_footer(); ?>
</body>
</html>
