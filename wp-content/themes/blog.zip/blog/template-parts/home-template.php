<?php
    /*
    Template Name: Home Template
    */

    get_header();
    
    include(get_template_directory() . "/comp/home/inicio.php");

    get_footer();
