<?php include(get_template_directory() . "/comp/home/seccion-principal.php") ?>
<?php include(get_template_directory() . "/comp/home/seccion-secundario.php") ?>
<?php include(get_template_directory() . "/comp/home/seccion-tercera.php") ?>
<?php include(get_template_directory() . "/comp/home/seccion-cuarta.php") ?>